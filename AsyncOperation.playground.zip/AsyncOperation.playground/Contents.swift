import UIKit
import Dispatch

final class Atomic<T> {
    private var value: T
    private let queue: DispatchQueue
    
    init(value: T, queue: DispatchQueue? = nil) {
        self.value = value
        self.queue = DispatchQueue(label: "com.Atomic.Queue", target: queue)
    }
}

extension Atomic {
    func mutate(_ transform: (inout T) -> Void) {
        queue.sync {
            transform(&value)
        }
    }
}

extension Atomic {
    var atomic: T {
        return queue.sync {
            value
        }
    }
}

extension Atomic: Equatable where T: Equatable {
    static func ==(lhs: Atomic, rhs: Atomic) -> Bool {
        return lhs.atomic == rhs.atomic
    }
}

extension Atomic: Hashable where T: Hashable {
    var hashValue: Int {
        return atomic.hashValue
    }
}

class AsyncOperation: Operation {
    private enum State: String {
        case ready
        case executing
        case finished
        
        var key: String {
            return "is" + self.rawValue.capitalized
        }
    }
    
    private let queue = DispatchQueue(label: "come.some.some.AsyncOperation")
    private var _state: Atomic<State> = Atomic(value: .ready)
    private var state: State {
        get {
            return _state.atomic
        }
        set {
            queue.sync {
                let oldValue = _state.atomic
                guard newValue != oldValue else {
                    return
                }
                
                willChangeValue(forKey: oldValue.key)
                willChangeValue(forKey: newValue.key)
                
                _state.mutate { $0 = newValue }
                
                didChangeValue(forKey: oldValue.key)
                didChangeValue(forKey: newValue.key)
            }
        }
    }
    
    override var isAsynchronous: Bool {
        return true
    }
    
    override var isExecuting: Bool {
        return state == .executing
    }
    
    override var isFinished: Bool {
        return state == .finished
    }
    
    override var isReady: Bool {
        return state == .ready
    }
    
    override func start() {
        if isCancelled {
            state = .finished
            return
        }
        
        main()
    }
    
    override func main() {
        if isCancelled {
            state = .finished
            return
        }
        
        state = .executing
        execute { [weak self] in
            self?.state = .finished
        }
    }
    
    func execute(completion: @escaping () -> Void) {
        fatalError("Must been overridden")
    }
}
